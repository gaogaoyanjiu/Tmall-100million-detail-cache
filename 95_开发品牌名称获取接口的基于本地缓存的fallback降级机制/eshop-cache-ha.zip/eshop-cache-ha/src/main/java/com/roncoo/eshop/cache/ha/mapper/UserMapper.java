package com.roncoo.eshop.cache.ha.mapper;

public interface UserMapper {

}
