package com.roncoo.eshop.inventory.request;

/**
 * 请求接口
 * @author Administrator
 *
 */
public interface Request {
	
	void process();
	
}
