package com.roncoo.eshop.inventory.dao.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import redis.clients.jedis.JedisCluster;

import com.roncoo.eshop.inventory.dao.RedisDAO;

@Repository("redisDAO")
public class RedisDAOImpl implements RedisDAO {

	@Resource
	private JedisCluster jedisCluster;
	
	@Override
	public void set(String key, String value) {
		String info = jedisCluster.set(key, value);
		System.out.println("================================  set key " + info);
	}

	@Override
	public String get(String key) {
		return jedisCluster.get(key);
	}

}
